// Project identifier: AD48FB4835AF347EB0CA8009E24C3B13F8519882
#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_

using namespace std;

// PlanetClass related constants
const int BEST_JEDI_INDEX = 0;
const int BEST_SITH_INDEX = 1;
const int MAYBE_BEST_JEDI_INDEX = 2;
const int MAYBE_BEST_SITH_INDEX = 2;

#endif