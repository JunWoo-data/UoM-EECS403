Don't run long-quiet-input.txt without the -q/--quiet flag!
It produces a huge output file, and takes a long time to do it.

Execution times for our solution, running on the autograder:
    short-input.txt: 0.046s
    long-quiet-input.txt: 2.213s

We've also give you the specification input and output, along with
three "checkpoint" tests (input and output).  There is no required
date for completing the checkpoints, but these test cases do exist
on the autograder and will help you gauge your progress.
